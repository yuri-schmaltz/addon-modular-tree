#pragma once

namespace Mtree
{
	class GrowthInfo
	{
	public:
		virtual ~GrowthInfo() {}
	};
}