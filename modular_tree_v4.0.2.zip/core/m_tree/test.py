import m_tree
# import pickle



tree = m_tree.Tree()
trunk_function = m_tree.TrunkFunction()
tree.set_trunk_function(trunk_function)

